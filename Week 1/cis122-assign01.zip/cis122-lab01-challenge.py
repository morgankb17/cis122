'''
CIS 122 Fall 2019 Lab 1 Challenge
Author: Morgan Bartlett
Credit:
Description: Lab 1 Challenge
'''
# First original line of code
day = Monday          # Assign string to a variable
# Updated first original line of code
day = "Monday"

# Second line of code
square = 2 ^ 2        # Perform power operation
# Updated second line of code
square = 2 ** 2

# Third line of code
print square          # Output value of a variable
# Updated line of code
print(square)

# Fourth line of code
print(day + square)   # Target output is "Monday 4" (without quotation marks)
# Updated line of code
print(day, square)
