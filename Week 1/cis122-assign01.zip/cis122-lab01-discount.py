cost = 50
# type(cost)
discount = 0.10
# type(discount)
discounted_cost = cost - cost * discount
# discounted_cost # Display the variable discounted_cost value
print(discounted_cost) # Use the print() function to display the discounted_cost value
print("Discounted cost:", discounted_cost) # Use print() to output a label string and then the value
3 + 4

'''
'Lastname' + 'Firstname'
'Lastname' + ' ' + 'Firstname'     # The ' ' is a single space
3 * 'A'
3 * 4 * 'A'
2 * '4'
2 * 4
2.0 * 'AA'
0.50 * 'AA'
'Discount: ' + 45
'''
